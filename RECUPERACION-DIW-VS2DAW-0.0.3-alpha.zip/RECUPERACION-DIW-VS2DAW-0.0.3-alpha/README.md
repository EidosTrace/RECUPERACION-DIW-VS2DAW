# RECUPERACION-DIW-VS2DAW
Trabajo de recuperación en grupo de Diseño de Interfaces Web.

# Tecnologías usadas:
Hemos implementado el uso de tecnologías como CSS y JS. Además, hemos agregado la nomenclatura BEM, al contrario que en el proyecto original.
Enlace del proyecto original:
https://github.com/EidosTrace/TF-DIW---VS2DAW

También hemos actualizado drásticamente los esquemas, patrones y dado un nuevo estilo al diseño de la página. Esto se debe a que el diseño anterior lo hizo el otro integrante del grupo.
Además, se usa el contraste de Azul-Naranja neón, para resaltarse unos a otros en un fondo negro. Lo cuál mejora la visibilidad y legibilidad del texto.

# ¿DE QUÉ VA ESTO?
Esta página web, o conjunto, es un sitio web de apuestas. Es importante destacar que tiene una funcionalidad mínima, si no nula. Es meramente un diseño, que podría o no tener alguna implementación futura en un entorno real o de simulación.
En teoría, también podría usarse como testing de una red neural predictiva y el desempeño de un LLM(Large Lenguage Model) en conjunto como un sistema multiagente para asistir a los usuarios de la plataforma.

