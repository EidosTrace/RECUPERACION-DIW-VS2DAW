[
    {
        bets:{
            "bet_sport": "football",
            "bet_multiplier": 1.10,
            "bet_date": "2025-01-01",
            "bet_status": "abierta",
            "team1": "Team A",
            "team2": "Team B"
            },
            {
            "bet_sport": "basketball",
            "bet_multiplier": 1.15,
            "bet_date": "2025-01-01",
            "bet_status": "cerrada",
            "team1": "Team C",
            "team2": "Team D"
            },
            {
            "bet_sport": "basketball",
            "bet_multiplier": 1.20,
            "bet_date": "2025-01-02",
            "bet_status": "abierta",
            "team1": "Team E",
            "team2": "Team F"
            },
            {
            "bet_sport": "basketball",
            "bet_multiplier": 1.25,
            "bet_date": "2025-01-03",
            "bet_status": "cerrada",
            "team1": "Team G",
            "team2": "Team H"
            },
            {
            "bet_sport": "football",
            "bet_multiplier": 1.30,
            "bet_date": "2025-01-04",
            "bet_status": "abierta",
            "team1": "Team I",
            "team2": "Team J"
            },
            {
            "bet_sport": "tennis",
            "bet_multiplier": 1.35,
            "bet_date": "2025-01-05",
            "bet_status": "cerrada",
            "team1": "Player 1",
            "team2": "Player 2"
            },
            {
            "bet_sport": "tennis",
            "bet_multiplier": 1.40,
            "bet_date": "2025-01-06",
            "bet_status": "abierta",
            "team1": "Player 3",
            "team2": "Player 4"
            },
            {
            "bet_sport": "football",
            "bet_multiplier": 1.45,
            "bet_date": "2025-01-07",
            "bet_status": "cerrada",
            "team1": "Team K",
            "team2": "Team L"
            },
            {
            "bet_sport": "basketball",
            "bet_multiplier": 1.50,
            "bet_date": "2025-01-08",
            "bet_status": "abierta",
            "team1": "Team M",
            "team2": "Team N"
            },
            {
            "bet_sport": "football",
            "bet_multiplier": 1.55,
            "bet_date": "2025-01-09",
            "bet_status": "cerrada",
            "team1": "Team O",
            "team2": "Team P"
            }
        }
    }
]